<!-- featured-products.php -->
<section id="shop" class="py-20">
    <div class="container mx-auto text-center">
        
        
<?php get_template_part('components/shopby-category'); ?>
<?php get_template_part('components/shopby-brands'); ?>
<?php get_template_part('components/products-tab'); ?>

<?php get_template_part('components/shopby-age'); ?>
<?php get_template_part('components/products-popular-picks'); ?>
<?php get_template_part('components/home-banner-category'); ?>
<?php get_template_part('components/home-features-banner'); ?>


<?php get_template_part('components/testimonials-listing'); ?>
    
        
        
    </div>
</section>